clear all;
clc;
%%

C = read_file("vowdata_nohead.dat");
D_mod = create_classes(C);

k = 2;
cov_mat = 'full';

E8 = classification(D_mod, k, cov_mat);
E10 = classlist(D_mod, E8, k);
E11 = defineclass();
E12 = error_rate(E10, E11);
E15 = true_classified(E10, E11);

classLabels = {'ae','ah','aw','eh','er','ei','ih','iy','oa','oo','uh','uw'};
trueLabels = categorical(E15(:,1), 1:12, classLabels);
predictedLabels = categorical(E15(:,2), 1:12, classLabels);
cm = confusionchart(trueLabels, predictedLabels); 
cm.Title = ['Confusion matrix with k=', num2str(k), ' components and ', cov_mat,' covariance matrix '];

disp(['Error rate with k=', num2str(k), ' components and ', cov_mat,' covariance matrix ']);
X = [num2str(E12*100), '%'];
disp(X);

S = scatter_plot(D_mod);



%%

function plt = scatter_plot(D_mod)
    L = 139; 
    for i = 1:12
        %RGB = [i*1 i*6 i*9]/256 ;
        scatter(D_mod((i-1)*L +1: i*L, 1),D_mod((i-1)*L +1: i*L, 3));
        xlabel('F1');
        ylabel('F3');
        title('Scatterplot of the two formants F1 and F3 from each class');
        hold on;
    end
    hold off; 
    plt = [];
end

function position = true_classified(X, T)
    %funksjonen tek inn argumenta
    % X = output frå class_array funksjonen
    % T = faktisk klasse

    [row_guess, ~] = find(X > 0);
    [row_true, ~] = find(T > 0);
    position = [row_guess, row_true];
end


function error_rate = error_rate(X, T)
    %Funksjonen finn error rate
    %funksjonen tek inn argumenta
    % X = output frå class_array funksjonen
    % T = faktisk klasse

    L = length(X(1,:));

    D = X-T;
    col = find(D > 0);

    error_rate = length(col) / (L);
end

function T = defineclass()
    T = zeros(12,69*12);
    for j = 1:12
        T(j, (j-1)*69+1:j*69) = 1;
    end    
end

function classlist = classlist(D, GMM, num_class)
    L = 69*12;
    L1 = 139;
    L2 = 69;
    classlist = zeros(12, L);

    for j = 1:12 
        for i = 1:69
            D_i = D((j-1)*L1+70+i,:);
            class = classifier(D_i, GMM, num_class);
            classlist(class, (j-1)*L2 +i) = 1; 
        end
    end    
end

function class = classifier(D, GMM, num_class)
    %Denne tar inn ein stk vokal, tester den opp mot alle 12 klasser, og
    %gir ut den klassen som gir ML til vokal
    %Denne må ta inn GMM som er klassifiseringsvektoren fra funksjonen
    %classification

    N = num_class;
    class = 0; 
    mle1 = 0;
    mle = 0;

    for j = 1:12
        for n = 1:N
            mle = mle + GMM{j}.ComponentProportion(n)*mvnpdf(D, GMM{j}.mu(n,:), GMM{j}.Sigma(:,:,n));
            %GMM{j}.ComponentProportion(n);
        end
        if mle > mle1
            class = j;
            mle1 = mle;   
        end
        mle = 0; 
    end    
end

function GMM = classification(D, num_class, cov_type)
    %Denne funksjonen lager 12 forskjellige klasser med ulike parameter
    L = 139;
    GMM = cell(12,1);

    for j = 1:12
        rng('default');
        GMM{j} = fitgmdist(D((j-1)*L+1 :j*L-69 ,:), num_class, 'RegularizationValue', 0.1, 'Start','plus', CovarianceType=cov_type );

    end        
end



function D_mod = create_classes(C)

    L1 = length(C{1}(1:end,1));  %1668
    L2 = length(C);              %16
    P = L1/12;                   %139

    D = zeros(L1,L2-1);
    for j = 1:12
        for i = 1:15

            D((j-1)*P +1:j*P,i) = C{i+1}((j-1)*P +1:j*P,1);
        end
    end
    %ae’,’ah’,’aw’,’eh’,’er’,’ei’,’ih’,’iy’,’oa’,’oo’,’uh’,’uw’; 
    D_mod = D(1:end,3:5);
end


function C = read_file(filename)
    fileID = fopen(filename);
    C = textscan(fileID,'%s%4.1f%4.1f%4.1f%4.1f%4.1f%4.1f%4.1f%4.1f%4.1f%4.1f%4.1f%4.1f%4.1f%4.1f%4.1f', 1668);
    fclose(fileID);
    C{1} = char(C{1});
end
